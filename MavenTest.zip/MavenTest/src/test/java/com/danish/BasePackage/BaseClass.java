package com.danish.BasePackage;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class BaseClass {

	public static WebDriver driver;
	public static FileInputStream fis;
	public static Properties config = new Properties();
	
	@BeforeSuite
	public void startUp() throws IOException, InterruptedException {
		
		
		fis = new FileInputStream("E:\\workspace\\LearnSelenium\\MavenTest\\src\\test\\resources\\Config.properties");
		config.load(fis);
		String browserName = config.getProperty("browser");
		
		if(browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Danish\\Downloads\\chromedriver_85\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		else if(browserName.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\Danish\\Downloads\\chromedriver_85");
		}

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(config.getProperty("baseurl"));
	}

	@AfterSuite
	public void close() {
		
		driver.quit();
	}
}
