package com.smoke;

import org.testng.annotations.Test;

public class FirstRegression {

	@Test
	public void check() {
		System.out.println("Regression");
	}
}
