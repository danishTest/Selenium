package com.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.danish.BasePackage.BaseClass;

public class SecondTestCase extends BaseClass{

	@Test
	public void login() {
		
		
		WebDriverWait wait = new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("select-demo")));
		Select select = new Select(driver.findElement(By.id("select-demo")));
		select.selectByValue("Sunday");
		
	//	driver.findElement(By.cssSelector("")).sendKeys("abc");
		
	}
}
