package com.testcases;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.danish.BasePackage.BaseClass;

public class TestCase extends BaseClass{

	@BeforeMethod
	public void beforeMethod() {
		System.out.println("DB initialize");
	}
	
	@Test(dataProvider="inputdata",priority=2)
	public void login(String name,String id,String random) {
		
		System.out.println(name);
		System.out.println(id);
		System.out.println(random);
		
	//	driver.findElement(By.cssSelector("")).sendKeys("abc");
	}
	
	@DataProvider
	public Object[][] inputdata(){
		
		return new Object[][]{
			{"name","age","dhd"},
			};
	}
	
	
	
	@Test(priority=1)
	public void purchase() {
		System.out.println("Purchase");
		
	}
	
	@Test(priority=3)
	public void popUpWindow() throws InterruptedException {
		driver.get("https://www.seleniumeasy.com/test/");
		WebDriverWait wait = new WebDriverWait(driver,20);
		driver.findElement(By.cssSelector("#btn_basic_example")).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("#basic > div > a:nth-child(6)")));
		driver.findElement(By.cssSelector("#basic > div > a:nth-child(6)")).click();
		Thread.sleep(5*1000);
		System.setProperty("insuranceAmount", driver.findElement(By.xpath("//a[contains(text(),\"Follow On Twitter\")]")).getText());
		driver.findElement(By.xpath("//a[contains(text(),\"Follow On Twitter\")]")).click();
		Thread.sleep(5*1000);
		String mainWindowHandle = driver.getWindowHandle();
		Set<String> windows = driver.getWindowHandles();
		for(String w : windows) {
			
			if(!w.equalsIgnoreCase(mainWindowHandle)) {
				driver.switchTo().window(w);
				driver.findElement(By.xpath("(//input)[6]")).sendKeys(System.getProperty("insuranceAmount"));
				Thread.sleep(5*1000);
				driver.close();
			}
		}
		
		
	}
	@AfterMethod
	public void afterMethod() {
		System.out.println("Close DB");
	}
}
