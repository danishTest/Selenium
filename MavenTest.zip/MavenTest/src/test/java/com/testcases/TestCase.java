package com.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.danish.BasePackage.BaseClass;

public class TestCase extends BaseClass{

	@BeforeMethod
	public void beforeMethod() {
		System.out.println("DB initialize");
	}
	
	@Test(priority=2)
	public void login() {
		
		System.out.println("Login");
	//	driver.findElement(By.cssSelector("")).sendKeys("abc");
	}
	
	@Test(priority=1)
	public void purchase() {
		System.out.println("Purchase");
		
	}
	@AfterMethod
	public void afterMethod() {
		System.out.println("Close DB");
	}
}
